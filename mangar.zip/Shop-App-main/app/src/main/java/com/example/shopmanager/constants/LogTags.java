package com.example.shopmanager.constants;

public enum LogTags {
    DATABASE,
    LOGON,
    REGISTER
}
