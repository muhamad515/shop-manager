package com.example.shopmanager.constants;

public enum TaskResponses {
    SUCCESS,
    DATABASE_FAILED,
    ID_EXISTS
}
